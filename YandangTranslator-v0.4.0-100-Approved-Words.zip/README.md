# Yandang Translator — No-Login Community Prototype (Android)

This is a native Android / Kotlin / Jetpack Compose prototype.

## Account and privacy design
- The app opens directly; no registration or login is required.
- No username, password, email address, or phone number is collected.
- The current prototype has no authentication service or account screens.
- Contributions are saved locally on the device only; they are not uploaded.
- Contributor name is optional and can be left blank.

## What works in this prototype
- Four-screen app structure: Translate, Community Dictionary, Contribute, About.
- English/Yandang direction switch.
- Search of locally saved contribution drafts.
- Save word contributions on the device using Android SharedPreferences.
- Saved drafts remain on that phone without internet.
- Clear status labels: locally saved entries are **not verified** and are **not published**.

## What is not yet implemented
- There is no real translation engine or verified Yandang vocabulary bundled.
- There is no online account system, community moderator workflow, cloud database, or automatic sync. This is intentional for the current no-login version.
- There is no audio recording/playback feature yet.
- This project does not include a compiled APK.

## Language integrity
Do not invent translations or assume all communities use the same spelling or vocabulary. Confirm community/dialect names, orthography, meanings, and pronunciation with fluent speakers. Each contribution should include:
- English meaning
- Yandang word or phrase
- Community / dialect
- Contributor (optional, with consent)
- Usage or pronunciation notes
- Review status and reviewer(s), to be added in the backend

The app currently offers a neutral “Community/dialect to be confirmed” selector rather than presenting an unverified list of dialect names as final.

## Build
1. Install Android Studio on a computer.
2. Open this project folder.
3. Allow Gradle to sync.
4. Run on an Android phone or emulator.

To make an APK in Android Studio: **Build > Build Bundle(s) / APK(s) > Build APK(s)**.

## Suggested next milestone
Create a secure online backend and moderation workflow, then add a reviewed, downloadable dialect dictionary. Keep offline search and contribution drafts available without payment. Online syncing requires internet and should only upload after the contributor explicitly agrees.

## Build an APK using only an Android phone (cloud build)

This project includes `.github/workflows/android-apk.yml`. It lets GitHub's cloud runner compile the debug APK; no Android Studio or local Gradle installation is needed on your phone.

1. In your phone browser, sign in to GitHub or create a free account.
2. Create a **new public repository** named `YandangTranslator` (public repositories can use GitHub-hosted Actions at no charge within GitHub's current limits; check GitHub's current plan limits).
3. On the repository page, use **Add file → Upload files** and upload the contents of this ZIP (including the hidden `.github` folder). If the phone's file picker hides dot-folders, use GitHub's web editor to create `.github/workflows/android-apk.yml` and paste the workflow contents from this project.
4. Commit the files to the `main` branch.
5. Open the repository's **Actions** tab and select **Build Yandang Translator APK**. If asked, enable workflows, then tap **Run workflow**.
6. Wait for the run to finish successfully. Open the completed run and download the artifact named `Yandang-Translator-debug-APK`.
7. Extract the downloaded artifact ZIP and tap `app-debug.apk` to install it. Android may ask you to allow installs from your browser or file manager; only allow this for the APK you built from your own repository.

The APK produced this way is a **debug/testing APK**, not a Play Store release. Keep the repository private if you do not want the source code public; check GitHub's current Actions usage limits for private repositories.

Do not upload passwords, signing keys, or private personal data to the repository.


## Version 0.4.0 — community-approved dictionary

This build bundles 100 entries from the approved vocabulary spreadsheet. Translate supports exact single-word lookup in English→Yandang and Yandang→English directions. Dictionary searches the bundled approved list offline. Community contributions remain local drafts and are not mixed into approved translations. Phrase translation and audio are not included in this version.
