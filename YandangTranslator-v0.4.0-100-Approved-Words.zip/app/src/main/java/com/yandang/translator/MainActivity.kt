package com.yandang.translator

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Book
import androidx.compose.material.icons.filled.Groups
import androidx.compose.material.icons.filled.Translate
import androidx.compose.material.icons.filled.Info
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import org.json.JSONArray
import org.json.JSONObject

private val Forest = Color(0xFF174B35)
private val Leaf = Color(0xFF2D7650)
private val Gold = Color(0xFFD5A642)
private val Sand = Color(0xFFF5F0E3)
private val Ink = Color(0xFF243329)
private val dialectOptions = listOf("All dialects", "Community/dialect to be confirmed")

data class Contribution(
    val english: String,
    val yandang: String,
    val dialect: String,
    val contributor: String,
    val note: String
)

data class ApprovedWord(val category: String, val english: String, val yandang: String, val community: String)

private fun loadApprovedWords(context: android.content.Context): List<ApprovedWord> = try {
    val raw = context.assets.open("yandang_words.json").bufferedReader(Charsets.UTF_8).use { it.readText() }
    val array = JSONArray(raw)
    (0 until array.length()).map { i ->
        val obj = array.getJSONObject(i)
        ApprovedWord(obj.optString("category"), obj.optString("english"), obj.optString("yandang"), obj.optString("community"))
    }
} catch (_: Exception) { emptyList() }

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { YandangApp() }
    }
}

@Composable
fun YandangApp() {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("yandang_local", 0) }
    val approvedWords = remember { loadApprovedWords(context) }
    var tab by remember { mutableIntStateOf(0) }
    var direction by remember { mutableStateOf(true) }
    var dialect by remember { mutableStateOf("All dialects") }
    var query by remember { mutableStateOf("") }
    var english by remember { mutableStateOf("") }
    var yandang by remember { mutableStateOf("") }
    var community by remember { mutableStateOf("") }
    var contributor by remember { mutableStateOf("") }
    var note by remember { mutableStateOf("") }
    var message by remember { mutableStateOf("") }
    var contributions by remember {
        mutableStateOf(loadContributions(prefs.getString("contributions", "[]") ?: "[]"))
    }

    MaterialTheme(colorScheme = lightColorScheme(
        primary = Forest, secondary = Gold, background = Sand, surface = Color.White
    )) {
        Scaffold(
            containerColor = Sand,
            bottomBar = {
                NavigationBar(containerColor = Forest) {
                    NavigationBarItem(tab == 0, { tab = 0 }, icon = { Icon(Icons.Default.Translate, null) },
                        label = { Text("Translate") },
                        colors = navColors())
                    NavigationBarItem(tab == 1, { tab = 1 }, icon = { Icon(Icons.Default.Book, null) },
                        label = { Text("Dictionary") },
                        colors = navColors())
                    NavigationBarItem(tab == 2, { tab = 2 }, icon = { Icon(Icons.Default.Groups, null) },
                        label = { Text("Contribute") },
                        colors = navColors())
                    NavigationBarItem(tab == 3, { tab = 3 }, icon = { Icon(Icons.Default.Info, null) },
                        label = { Text("About") },
                        colors = navColors())
                }
            }
        ) { padding ->
            Column(Modifier.fillMaxSize().padding(padding)) {
                Column(Modifier.fillMaxWidth().background(Forest).padding(horizontal = 20.dp, vertical = 18.dp)) {
                    Text("YANDANG", color = Gold, fontSize = 12.sp, fontWeight = FontWeight.Bold, letterSpacing = 3.sp)
                    Text("Translator", color = Color.White, fontSize = 29.sp, fontWeight = FontWeight.Bold)
                    Text("Many communities • One shared heritage", color = Color(0xFFE7DFC9), fontSize = 13.sp)
                }
                when (tab) {
                    0 -> TranslateScreen(direction, { direction = !direction }, dialect, { dialect = it },
                        query, { query = it }, contributions, approvedWords)
                    1 -> DictionaryScreen(dialect, { dialect = it }, query, { query = it }, contributions, approvedWords)
                    2 -> ContributeScreen(
                        english, { english = it }, yandang, { yandang = it },
                        community, { community = it }, contributor, { contributor = it },
                        note, { note = it }, message, { message = it },
                        onSave = {
                            val item = Contribution(english.trim(), yandang.trim(), community.trim(),
                                contributor.trim(), note.trim())
                            val updated = contributions + item
                            contributions = updated
                            prefs.edit().putString("contributions", saveContributions(updated)).apply()
                            english = ""; yandang = ""; community = ""; contributor = ""; note = ""
                            message = "Saved on this phone. It is a draft awaiting community review; it has not been uploaded."
                        }
                    )
                    else -> AboutScreen(contributions.size)
                }
            }
        }
    }
}

@Composable
private fun navColors() = NavigationBarItemDefaults.colors(
    selectedIconColor = Gold, selectedTextColor = Color.White,
    unselectedIconColor = Color.White, unselectedTextColor = Color.White
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun DialectPicker(value: String, onChange: (String) -> Unit) {
    var expanded by remember { mutableStateOf(false) }
    ExposedDropdownMenuBox(expanded = expanded, onExpandedChange = { expanded = !expanded }) {
        OutlinedTextField(
            value = value, onValueChange = {}, readOnly = true, label = { Text("Dialect / community") },
            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded) },
            modifier = Modifier.menuAnchor().fillMaxWidth(), shape = RoundedCornerShape(14.dp)
        )
        ExposedDropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
            dialectOptions.forEach { option ->
                DropdownMenuItem(text = { Text(option) }, onClick = {
                    onChange(option); expanded = false
                })
            }
        }
    }
}

@Composable
private fun TranslateScreen(
    direction: Boolean, toggle: () -> Unit, dialect: String, setDialect: (String) -> Unit,
    query: String, setQuery: (String) -> Unit, contributions: List<Contribution>, approvedWords: List<ApprovedWord>
) {
    val result = approvedWords.firstOrNull { if (direction) it.english.equals(query.trim(), true) else it.yandang.equals(query.trim(), true) }
    Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Translate", fontSize = 22.sp, fontWeight = FontWeight.Bold, color = Ink)
        DialectPicker(dialect, setDialect)
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.Center) {
            Text(if (direction) "English" else "Yandang", color = Forest, fontWeight = FontWeight.Bold)
            TextButton(onClick = toggle) { Text("⇄ Switch", color = Leaf) }
            Text(if (direction) "Yandang" else "English", color = Forest, fontWeight = FontWeight.Bold)
        }
        OutlinedTextField(
            value = query, onValueChange = setQuery, modifier = Modifier.fillMaxWidth(),
            minLines = 3, label = { Text(if (direction) "Enter English word or phrase" else "Enter Yandang word or phrase") },
            shape = RoundedCornerShape(14.dp)
        )
        Card(colors = CardDefaults.cardColors(containerColor = Color.White)) {
            Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("TRANSLATION", color = Leaf, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                if (query.isBlank()) {
                    Text("Enter a word to search the 100 community-approved entries.", color = Ink)
                } else if (result != null) {
                    Text(if (direction) result.yandang else result.english, color = Ink, fontSize = 25.sp, fontWeight = FontWeight.Bold)
                    Text("Category: ${result.category} • Community-approved", color = Forest, fontSize = 12.sp)
                } else {
                    Text("No approved match found for this word yet.", color = Ink)
                    Text("Try a single word from the dictionary. This version looks up exact word matches.", color = Color.Gray, fontSize = 12.sp)
                }
                Text("Only the approved word list is used for translations. Local contributions remain separate until reviewed.", color = Color.Gray, fontSize = 12.sp)
            }
        }
        Text("Offline access: entries saved on this phone remain available without internet.",
            color = Forest, fontSize = 12.sp)
    }
}

@Composable
private fun DictionaryScreen(
    dialect: String, setDialect: (String) -> Unit, query: String, setQuery: (String) -> Unit,
    contributions: List<Contribution>, approvedWords: List<ApprovedWord>
) {
    val filteredApproved = approvedWords.filter { query.isBlank() || it.english.contains(query, true) || it.yandang.contains(query, true) }
    val filtered = contributions.filter {
        (dialect == "All dialects" || it.dialect.equals(dialect, true)) &&
            (query.isBlank() || it.english.contains(query, true) || it.yandang.contains(query, true))
    }
    Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("Community dictionary", fontSize = 22.sp, fontWeight = FontWeight.Bold, color = Ink)
        DialectPicker(dialect, setDialect)
        OutlinedTextField(query, setQuery, modifier = Modifier.fillMaxWidth(),
            label = { Text("Search English or Yandang") }, singleLine = true)
        Text("${filteredApproved.size} approved words • ${filtered.size} local draft(s)", color = Forest, fontSize = 12.sp)
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(filteredApproved) { item ->
                Card(colors = CardDefaults.cardColors(containerColor = Color.White)) {
                    Column(Modifier.fillMaxWidth().padding(14.dp)) {
                        Text(item.english, color = Leaf, fontWeight = FontWeight.Bold)
                        Text(item.yandang, color = Ink, fontSize = 20.sp)
                        Text("Category: ${item.category}", color = Color.Gray, fontSize = 12.sp)
                        Text("Status: community-approved", color = Forest, fontSize = 11.sp)
                    }
                }
            }
            items(filtered) { item ->
                Card(colors = CardDefaults.cardColors(containerColor = Color.White)) {
                    Column(Modifier.fillMaxWidth().padding(14.dp)) {
                        Text(item.english, color = Leaf, fontWeight = FontWeight.Bold)
                        Text(item.yandang, color = Ink, fontSize = 19.sp)
                        Text("Community: ${item.dialect}", color = Color.Gray, fontSize = 12.sp)
                        if (item.note.isNotBlank()) Text(item.note, color = Color.Gray, fontSize = 12.sp)
                        Text("Status: local draft — not yet verified", color = Color(0xFF8A5A00), fontSize = 11.sp)
                    }
                }
            }
        }
    }
}

@Composable
private fun ContributeScreen(
    english: String, setEnglish: (String) -> Unit,
    yandang: String, setYandang: (String) -> Unit,
    community: String, setCommunity: (String) -> Unit,
    contributor: String, setContributor: (String) -> Unit,
    note: String, setNote: (String) -> Unit,
    message: String, setMessage: (String) -> Unit,
    onSave: () -> Unit
) {
    Column(Modifier.fillMaxSize().padding(16.dp).imePadding(), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("Contribute a word", fontSize = 22.sp, fontWeight = FontWeight.Bold, color = Ink)
        Text("Help preserve every community's way of speaking. Please submit only words you know or can verify.",
            color = Ink, fontSize = 13.sp)
        OutlinedTextField(english, setEnglish, modifier = Modifier.fillMaxWidth(),
            label = { Text("English meaning") }, singleLine = true)
        OutlinedTextField(yandang, setYandang, modifier = Modifier.fillMaxWidth(),
            label = { Text("Yandang word or phrase") }, singleLine = true)
        OutlinedTextField(community, setCommunity, modifier = Modifier.fillMaxWidth(),
            label = { Text("Community / dialect name") }, singleLine = true)
        OutlinedTextField(contributor, setContributor, modifier = Modifier.fillMaxWidth(),
            label = { Text("Contributor name (optional)") }, singleLine = true)
        OutlinedTextField(note, setNote, modifier = Modifier.fillMaxWidth(),
            label = { Text("Pronunciation or usage note (optional)") }, minLines = 2)
        Button(
            onClick = onSave, enabled = english.isNotBlank() && yandang.isNotBlank() && community.isNotBlank(),
            modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Forest)
        ) { Text("Save contribution on this phone") }
        if (message.isNotBlank()) Text(message, color = Forest, fontSize = 12.sp)
        Text("Important: saving here does not publish or verify the entry. Online community review and syncing will be added in a later release.",
            color = Color.Gray, fontSize = 11.sp)
    }
}

@Composable
private fun AboutScreen(savedCount: Int) {
    Column(Modifier.fillMaxSize().padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("About this project", fontSize = 22.sp, fontWeight = FontWeight.Bold, color = Ink)
        Text("Yandang Translator is being built as a free community language-preservation tool.",
            color = Ink)
        listOf(
            "All communities and dialects should be represented.",
            "Native speakers should review translations for their own variety.",
            "Offline dictionaries and lessons should be free.",
            "Community names and dialect relationships must be confirmed by speakers.",
            "No invented or unverified translations will be presented as facts."
        ).forEach { point ->
            Card(colors = CardDefaults.cardColors(containerColor = Color.White)) {
                Text("•  $point", Modifier.padding(14.dp), color = Ink)
            }
        }
        Text("Local contribution drafts saved on this phone: $savedCount", color = Forest, fontWeight = FontWeight.SemiBold)
        Text("This version includes 100 community-approved dictionary entries and offline exact-word lookup. Phrase translation, audio, and online syncing are not included yet.",
            color = Color.Gray, fontSize = 12.sp)
    }
}

private fun saveContributions(items: List<Contribution>): String {
    val array = JSONArray()
    items.forEach { item ->
        array.put(JSONObject().apply {
            put("english", item.english); put("yandang", item.yandang)
            put("dialect", item.dialect); put("contributor", item.contributor); put("note", item.note)
        })
    }
    return array.toString()
}

private fun loadContributions(raw: String): List<Contribution> = try {
    val array = JSONArray(raw)
    (0 until array.length()).map { index ->
        val obj = array.getJSONObject(index)
        Contribution(obj.optString("english"), obj.optString("yandang"),
            obj.optString("dialect"), obj.optString("contributor"), obj.optString("note"))
    }
} catch (_: Exception) { emptyList() }
